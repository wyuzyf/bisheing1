int cvFindChessboardCorners3( const void* arr, CvSize pattern_size,
                             CvPoint2D32f* out_corners, int* out_corner_count,
                             int min_number_of_corners );
